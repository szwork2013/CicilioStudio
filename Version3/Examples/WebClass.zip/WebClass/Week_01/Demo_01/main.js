/**
 * Created by Lance on 7/10/2015.
 */
var hello = function(){
    var element = document.getElementById('magic');
    element.innerText += "Hello World";
    element.innerText += "\nHello World!";
};

window.onload = function() {
    hello();
};