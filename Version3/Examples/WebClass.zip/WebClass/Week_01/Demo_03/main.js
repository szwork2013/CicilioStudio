/**
 * Created by Lance on 7/10/2015.
 */
var makeMyElement = function(){
    var element = document.createElement('div');
    element.innerText += "Hello World";

    //element.setAttribute("id","magic");

    document.body.appendChild(element);
};

window.onload = function() {
    makeMyElement();
};