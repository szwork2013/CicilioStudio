/**
 * Created by Lance on 7/10/2015.
 */
var makeMyElement = function(){
    var element = document.createElement('div');
    element.innerText += "Hello World";

    //document.body.appendChild(element);
};

window.onload = function() {
    makeMyElement();
};