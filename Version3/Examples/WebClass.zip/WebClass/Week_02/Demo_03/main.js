/**
 * Created by Lance on 7/10/2015.
 */
var makeMyElement = function(){
    //console.log("The Page Loaded!");
};

window.onload = function() {
    makeMyElement();
};

/**
 *
 * @param e - a javascript event
 */
var printEvent = function(e){
    console.log(e.type);
};