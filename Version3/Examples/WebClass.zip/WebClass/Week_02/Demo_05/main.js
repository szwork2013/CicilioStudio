/**
 * Created by Lance on 7/10/2015.
 */
var makeMyElement = function(){
    //console.log("The Page Loaded!");
};



var printEvent = function(e){
    console.log(e.type);
};

var changeID = function(element){
    var currentID = element.getAttribute('id');

    //Some regex
    var newID = currentID.toString().replace(/([a-z]|[A-Z]\w)/g,''); //Learn at http://regexr.com/
    var finalID = currentID.replace(/([0-9])/g,'');
    var newIDNum = parseInt(newID) + 1;

    // Conditional if statement
    if (newIDNum > 3){
        newIDNum = 1;
    }

    finalID = finalID + newIDNum.toString();

    debugger;
    element.setAttribute('id',(finalID).toString());
};




//var printSubmittedData = function() {
//    var form = document.getElementById('myForm');
//    form.submit(function(){
//        var results = document.getElementById('results');
//        results.innerText = '';
//        var children = form.childNodes.getElementsByTagName('input');
//
//        children.forEach(function(child){
//            if (child.tagName == 'input'){
//                results.innerText = (child.type + " " + child.value);
//            };
//        });
//        debugger;
//    });
//};


window.onload = function() {
    makeMyElement();
    printSubmittedData();
};

