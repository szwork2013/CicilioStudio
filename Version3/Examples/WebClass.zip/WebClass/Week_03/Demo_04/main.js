var displayText = function(){
    var textbox = $('.text');
    var text = textbox.val();
    var newList = $('<li></li>');
    newList.html(text);
    $('.display').append(newList);
    textbox.val('');
    textbox.focus();
};