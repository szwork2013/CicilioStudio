var displayText = function(){
    var textbox = document.getElementsByClassName('text')[0];
    var text = textbox.value;
    var newList = document.createElement('li');
    newList.innerHTML += text;
    document.getElementsByClassName('display')[0].appendChild(newList);
    textbox.value = "";
    textbox.focus();
};