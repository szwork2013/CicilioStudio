"""
Name: For_Loop.py
Author: Dominic Cicilio
Language: Python 3.3
"""

#For Loop with a range of 5
# It should print out 0 to 4
for i in range(0,5):
    print("i equals: " + str(i))
    
print("-----------------------------")



ans = 0
pre1 = 0
pre2 = 1
for i in range(0,5):
    if (i % 2 == 0):
        pre1 = pre1 + pre2
        ans = pre1
    else:
        pre2 = pre1 + pre2
        ans = pre2

print(ans)


#For Loop with a range of 10
# It should print out -5 to 5
for i in range(-5,5):
    print("i equals: " + str(i))
print("-----------------------------")

#Cordinate List -- a cordinate equivalent to (x,y)

testList = [5,4,8,2,3,4]
testString = "HelloWorld"
print (testString[5])

cordList = ([[0,0],[5,5],[2,8],[4,8],[1,9]])
tempList = [3,6,5,7,8,4]

for cord in cordList:
    print (cord)


for cord in cordList:
    x = cord[0]
    y = cord[1]
    print("The x value = " + str(x))
    print("The y value = " + str(y))
    print()
"""
#Populate Strings with New Lines
myStr = ""
size = 10
for line in range(0,size):
    myStr += (size * '-') + '\n'

myStr += "+"
print (myStr)

index = 0
newStr = ""
for cord in cordList:
    x = cord[0]
    y = cord[1]
    temp = myStr.split('\n')
    
    
    for k in range(0,size-1):
        if (y == k):
            myStr = myStr[:5].replace("-",'*')
    index += 10
    
print (myStr)
"""

"""
# Creating Neat Outputs
s = ""
for j in range(0,30):
    s = ""
    
"""
