"""
Name: While_Loop.py
Author: Dominic Cicilio
Language: Python 3.3
"""

#While Loop

value = 0
while (value < 10):
    print(value)
    value += 1

print("-----------------------------")



while (True):
    value = str(input("Is the sky blue? (y,n): "))
    if (value == "y"):
        print("What a nice day\n")
    elif (value == "n"):
        print("That is too bad\n")
    else:
        print("Wrong input, please only use 'y' or 'x'\n")

    value = str(input("Do you want to exit? (y,n): "))
    if (value == 'y'):
        print("Goodbye")
        break
    else:
        print("Lets continue then\n")
